document.addEventListener('DOMContentLoaded', function() {
    
    const advantageItems = document.querySelectorAll('.advantage-item');
    
    advantageItems.forEach(item => {
        const header = item.querySelector('.advantage-item-header');
        
        header.addEventListener('click', () => {
            item.classList.toggle('active');
            
            const icon = header.querySelector('.toggle-icon');
            if (item.classList.contains('active')) {
                
                icon.textContent = '↓';
            } else {
                icon.textContent = '→';
            }
        });
    });

    
    
    const toggleButtons = document.querySelectorAll('.toggle-btn');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const caseItem = this.closest('.case-item');
            
            caseItem.querySelectorAll('.toggle-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            this.classList.add('active');
            
            const viewType = this.dataset.view;
            
            const beforeImage = caseItem.querySelector('.before');
            const afterImage = caseItem.querySelector('.after');
            
            if (viewType === 'before') {
                beforeImage.style.opacity = '1';
                afterImage.style.opacity = '0';
            } else {
                beforeImage.style.opacity = '0';
                afterImage.style.opacity = '1';
            }
        });
    });

    
    function initGallery(galleryId, scrollStep = 400) {
        const gallery = document.getElementById(galleryId);
        const arrowsContainer = gallery.closest('.operation-container, .doctors-container').querySelector('.navigation-arrows');
        const arrowLeft = arrowsContainer.querySelector('.arrow-left');
        const arrowRight = arrowsContainer.querySelector('.arrow-right');
        
        let isDown = false;
        let startX;
        let scrollLeft;

        
        gallery.addEventListener('mousedown', (e) => {
            isDown = true;
            startX = e.pageX - gallery.offsetLeft;
            scrollLeft = gallery.scrollLeft;
            gallery.style.scrollBehavior = 'auto';
        });

        gallery.addEventListener('mouseleave', () => {
            isDown = false;
        });

        gallery.addEventListener('mouseup', () => {
            isDown = false;
            gallery.style.scrollBehavior = 'smooth';
        });

        gallery.addEventListener('mousemove', (e) => {
            if(!isDown) return;
            e.preventDefault();
            const x = e.pageX - gallery.offsetLeft;
            const walk = (x - startX) * 2;
            gallery.scrollLeft = scrollLeft - walk;
        });

        
        gallery.addEventListener('touchstart', (e) => {
            isDown = true;
            startX = e.touches[0].pageX - gallery.offsetLeft;
            scrollLeft = gallery.scrollLeft;
            gallery.style.scrollBehavior = 'auto';
        });

        gallery.addEventListener('touchend', () => {
            isDown = false;
            gallery.style.scrollBehavior = 'smooth';
        });

        gallery.addEventListener('touchmove', (e) => {
            if(!isDown) return;
            const x = e.touches[0].pageX - gallery.offsetLeft;
            const walk = (x - startX) * 2;
            gallery.scrollLeft = scrollLeft - walk;
        });

      
        arrowLeft.addEventListener('click', () => {
            gallery.scrollBy({
                left: -scrollStep,
                behavior: 'smooth'
            });
        });

        arrowRight.addEventListener('click', () => {
            gallery.scrollBy({
                left: scrollStep,
                behavior: 'smooth'
            });
        });
    }

   
    initGallery('gallery');
    initGallery('doctors-gallery', 450); 
});

function applyPhoneMask(input) {
    input.addEventListener('input', function(e) {
        
        let phone = this.value.replace(/\D/g, '');
        
        
        if (phone.length > 0 && phone[0] !== '7') {
            phone = '7' + phone;
        }
        
        
        let formattedPhone = '';
        if (phone.length > 0) {
            formattedPhone = '+7 (' + phone.substring(1, 4);
        }
        if (phone.length >= 4) {
            formattedPhone += ') ' + phone.substring(4, 7);
        }
        if (phone.length >= 7) {
            formattedPhone += '-' + phone.substring(7, 9);
        }
        if (phone.length >= 9) {
            formattedPhone += '-' + phone.substring(9, 11);
        }
        
        
        this.value = formattedPhone;
    });
    
    
    input.addEventListener('focus', function() {
        if (this.value === '') {
            this.value = '+7 (';
        }
    });
    
    
    input.addEventListener('blur', function() {
        if (this.value === '+7 (') {
            this.value = '';
        }
    });
}


const phoneInputs = document.querySelectorAll('input[type="text"][placeholder="Номер телефона"]');
phoneInputs.forEach(applyPhoneMask);

const signUpButtons = document.querySelectorAll('.sign-up');
    
signUpButtons.forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        
        const form = this.closest('.form-inputs') || this.closest('.smile-bt') || this.closest('.whatis-actions');
        let isValid = true;
        
        if (form) {
            const inputs = form.querySelectorAll('input[required]');
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                }
            });
            
            const consentCheckbox = form.querySelector('input[type="checkbox"]');
            if (consentCheckbox && !consentCheckbox.checked) {
                isValid = false;
            }
        }
        
        if (isValid) {
            alert('Регистрация прошла успешно!');
            
            
            if (form) {
                const allInputs = form.querySelectorAll('input');
                allInputs.forEach(input => {
                    if (input.type !== 'checkbox') {
                        input.value = '';
                    } else {
                        input.checked = false;
                    }
                });
            }
        } else {
            alert('Пожалуйста, заполните все обязательные поля!');
        }
    });
});